package com.cognizant.truyum.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static Date convertToDate() throws ParseException
	{
		 String sDate1="31/12/1998";  
		 Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);  
		    
		return date1;
	}

}
