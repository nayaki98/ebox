function validateForm() {
    let name = document.myForm.name.value;
    let password = document.myForm.password.value;
    let regex = /^[a-zA-Z]+$/;
    let l = name.length;
    if (name == "") {
        alert("Name cannot be empty");
        return false;
    }
    if (false == isNaN(name)) {
        alert("Name cannot have numbers");
        return false;
    }
    if (/[^a-zA-Z\-\/]/.test(name)) {
        alert("Name cannot have special characters");
        return false;
    }

    if (l < 2 || l > 30) {
        alert("Name length should be between 2 to 30 characters");
        return false;
    }
    if (password == "") {
        alert("Password cannot be empty")
        return false;
    }
   alert("Details Submitted Successfully")
}
