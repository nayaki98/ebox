import java.util.*;
import java.io.*;
public class ProfitCalculation
{
    public static void main(String arg[])
    {
      double buyingPrice;
      double sellingPrice;
      buyingPrice= 20.54;
      sellingPrice=30.50;
      System.out.println("Buying price is "+buyingPrice);
      System.out.println("Selling price is "+sellingPrice);
    }
}