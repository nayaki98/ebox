package org.cts.string;

import java.util.Scanner;

public class ReplaceOrganizationName {

	public static void main(String[] args) {
		String oldName,newName,content;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the content of the document");
		content=sc.nextLine();
		System.out.println("Enter the old name of the company");
		oldName=sc.next();
		System.out.println("Enter the new name of the company");
		newName=sc.next();
		System.out.println("The content of the modified document is");
		System.out.println(content.replace(oldName, newName));
	}

}
