package org.cts.string;

import java.util.Scanner;

public class TheRedCrossforeachloop {

	public static void main(String[] args) {
		int n,i,sum=0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int number[]=new int[n];
		for(i = 0; i < n; i++)
            number[i] = sc.nextInt();
		
		for (Integer ele : number)
			sum=sum+ele;
		
        System.out.println(sum);

	}
}
