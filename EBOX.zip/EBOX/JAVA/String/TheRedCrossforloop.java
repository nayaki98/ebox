package org.cts.string;

import java.util.Scanner;

public class TheRedCrossforloop {

	public static void main(String[] args) {
		int n,i,sum=0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int number[]=new int[n];
		for(i = 0; i < n; i++)
        {
            number[i] = sc.nextInt();
            sum = sum + number[i];
        }
        System.out.println(sum);
	}

}
