package org.cts.string;

import java.util.Scanner;

public class TheRedCrosswhileloop {

	public static void main(String[] args) {
		int n,i=0,sum=0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int number[]=new int[n];
		while(i<n)
        {
            number[i] = sc.nextInt();
            sum = sum + number[i];
            i++;
        }
        System.out.println(sum);

	}

}
