package org.cts.string;

import java.util.Scanner;

public class SecureURL {

	public static void main(String[] args) {
		String url,startString;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		url=sc.nextLine();
		System.out.println("Enter the start string");
		startString=sc.nextLine();
		if(url.startsWith("https"))
		{
			System.out.println("\""+url+"\" starts with \"https\"");
		}
		else
		{
			System.out.println("\""+url+"\" does not starts with \"https\"");
		}

	}

}
