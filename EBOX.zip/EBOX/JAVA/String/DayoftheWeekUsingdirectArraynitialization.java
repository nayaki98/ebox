package org.cts.string;

import java.util.Scanner;

public class DayoftheWeekUsingdirectArraynitialization {

	public static void main(String[] args) {
		String[] weekDays ={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
		int day;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the day number");
		day=sc.nextInt();
		System.out.println(weekDays[day-1]);
	}

}
