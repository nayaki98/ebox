package org.cts.string;

import java.util.Scanner;

public class DayoftheWeekUsingnewkeyword {

	public static void main(String[] args) {
		String[] weekDays = new String[7]; 
		weekDays[0]="Sun";
		weekDays[1]="Mon";
		weekDays[2]="Tue";
		weekDays[3]="Wed";
		weekDays[4]="Thu";
		weekDays[5]="Fri";
		weekDays[6]="Sat";
		int day;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the day number");
		day=sc.nextInt();
		System.out.println(weekDays[day-1]);

	}

}
