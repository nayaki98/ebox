package org.cts.keyword;

import java.util.Scanner;

public class DiscountCalculation {
	public static void main(String[] args) {
		float item1,item2,total,saved,amount;
		int discount;
		Scanner sc=new Scanner(System.in);
		System.out.println("Price of item 1 : ");
		item1=sc.nextFloat();
		System.out.println("Price of item 2 :");
		item2=sc.nextFloat();
		System.out.println("Discount in percentage : ");
		discount=sc.nextInt();
		total=item1+item2;
		saved=(float)total/discount;
		amount=total-saved;
		System.out.printf("Total amount : $%.2f\n",total);
		System.out.printf("Discounted amount : $%.2f\n",amount);
		System.out.printf("Saved amount : $%.2f",saved);
	}
}