package org.cts.keyword;

import java.util.Scanner;

public class LabAllocation {

	public static void main(String[] args) {
		int x,y,z;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter x");
		x=sc.nextInt();
		System.out.println("Enter y");
		y=sc.nextInt();
		System.out.println("Enter z");
		z=sc.nextInt();
		if(x<y && x<z)
			System.out.println("L1 has the minimal seating capacity");
		else if(y<x && y<z)
			System.out.println("L2 has the minimal seating capacity");
		else 
			System.out.println("L3 has the minimal seating capacity");
	}

}
