function validateForm()
{
    var title=document.editMovie.title.value;
    var boxOffice=document.editMovie.boxOffice.value;
    var dol=document.editMovie.dol.value;
    var genre=document.editMovie.genre.value;
if(title=="")
{
    alert("Title is required");
    return false;
}
if(title.length >100 && title.length < 0)
{
    alert("Title should have 2 to 100 characters");
    return false;
}
if(boxOffice=="")
{
    alert("boxOffice is required");
    return false;
}
if (isNaN(boxOffice)) {
    alert("Box Office has to be a number");
    return false;
}
if(dol=="")
{
    alert("Date of Launch is required");
    return false;
}
if(genre=="")
{
    alert("Select one genre");
    return false;
}
return true;
}