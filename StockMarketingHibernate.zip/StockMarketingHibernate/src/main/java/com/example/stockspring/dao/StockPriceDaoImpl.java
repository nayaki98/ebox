package com.example.stockspring.dao;
/*
public class StockPriceDaoImpl implements StockPriceDao {

}
*/