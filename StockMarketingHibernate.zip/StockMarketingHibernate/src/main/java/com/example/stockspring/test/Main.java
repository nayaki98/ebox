package com.example.stockspring.test;
//package com.examples.stockspring.test;
//
//import com.example.stockspring.controller.CompanyController;
//import com.example.stockspring.controller.CompanyControllerImpl;
//import com.example.stockspring.model.Company;
//
//public class Main {
//
//	public static void main(String[] args) throws Exception {
//		Company company=new Company();
//		CompanyController controller =new CompanyControllerImpl();
//		company.setCompanyName("XYZ");
//		company.setTurnOver(1115.26);
//		company.setCeo("Suresh");
//		company.setBoardOfDirectors("Kaveen");
//		company.setSectorId(11);
//		company.setBriefWriteup("abc");
//		company.setStockCode(123);
//		controller.insertCompany(company);
////		System.out.println(controller.getCompanyList());
//		boolean result=controller.updateCompamy(2, "Naveen");
//		if(result==true)
//			System.out.println("Update SuccessFully");
//		else
//			System.out.println("Update Failed");
//		if(controller.removeCompanyDetails(2))
//			System.out.println("Deleted Successfully");
//		else
//			System.out.println("Delete Failed");
//		
//
//	}
//
//}
