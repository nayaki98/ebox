package com.example.stockspring.controller;

public interface StockPriceController {

}
