package com.example.stockspring.service;


import com.example.stockspring.model.StockPrice;

public interface StockPriceService {

	void insertStockPriceDetail(StockPrice stockprice);

}
