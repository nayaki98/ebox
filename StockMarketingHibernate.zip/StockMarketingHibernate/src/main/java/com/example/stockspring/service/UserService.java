package com.example.stockspring.service;

import com.example.stockspring.model.User;

public interface UserService {

	void loginUser(User user);


}
