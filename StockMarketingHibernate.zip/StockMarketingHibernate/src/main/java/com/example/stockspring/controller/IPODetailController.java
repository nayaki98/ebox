package com.example.stockspring.controller;

import java.sql.SQLException;

import com.example.stockspring.model.IPODetail;

public interface IPODetailController {
	//public void insertIPODetail(IPODetail ipo) throws SQLException;
}
