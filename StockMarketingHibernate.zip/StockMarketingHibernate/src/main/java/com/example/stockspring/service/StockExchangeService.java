package com.example.stockspring.service;

import javax.validation.Valid;

import com.example.stockspring.model.StockExchange;

public interface StockExchangeService {


	void insertStockexchange(StockExchange stockExchange);

}
