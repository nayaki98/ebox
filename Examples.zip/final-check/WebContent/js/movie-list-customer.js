const movieList = [
    {
        title: 'Avatar', boxOffice: '$2,787,956,087', genre: 'Science Fiction', hasTeaser: 'Yes'
    },

    {
        title: 'The Avengers', boxOffice: '$1,518,812,988', genre: 'Superhero', hasTeaser: 'No'
    },

   {
        title: 'Titanic', boxOffice: '$2,187,463,944',  genre: 'Romance', hasTeaser: 'No'
    }

];

let productFromStroage=localStorage.getItem('movieList');
if(productFromStroage===null)
{
    localStorage.setItem('movieList',JSON.stringify(movieList));
}
productFromStroage=JSON.parse(productFromStroage)
const renderProducts = function (productFromStroage) {
    let tabE1 = document.querySelector("#movie-tab");

    productFromStroage.forEach(function (movie) {
        let trow1 = document.createElement("tr");
        let tcol1 = document.createElement("td");
        tcol1.textContent = movie.title;
        trow1.appendChild(tcol1);

        let tcol2 = document.createElement("td");
        tcol2.textContent = movie.boxOffice;
        trow1.appendChild(tcol2);

        let tcol3 = document.createElement("td");
        tcol3.textContent = movie.genre;
        trow1.appendChild(tcol3);

        let tcol4 = document.createElement("td");
        tcol4.textContent = movie.hasTeaser;
        trow1.appendChild(tcol4);

        let link = document.createElement("a");
        link.href = "movie-list-customer-notification.html?"+"title="+movie.title+"&boxOffice="+movie.boxOffice+"&genre="+movie.genre+"&hasTeaser="+movie.hasTeaser;
        let tcol5 = document.createElement("td");
        link.textContent = "Add to Favorite";
        tcol5.appendChild(link);

        trow1.appendChild(tcol5);

        tabE1.appendChild(trow1);

   })


}
renderProducts(productFromStroage);