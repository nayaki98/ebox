const movies = [
    {
        title: 'Avatar', boxOffice: '$2,787,956,087', Active: 'Yes', dataofLaunch: '15/03/2017', genre: 'Science Fiction',
        hasTeaser: 'Yes'
    },

    {
        title: 'The Avengers', boxOffice: '$1,518,812,988', Active: 'Yes', dataofLaunch: '23/12/2017', genre: 'Superhero',
        hasTeaser: 'No'
    },

    {
        title: 'Titanic', boxOffice: '$2,187,463,944', Active: 'Yes', dataofLaunch: '21/08/2017', genre: 'Romance',
        hasTeaser: 'No'
    },

    {
        title: 'Jurasic World', boxOffice: '$1,671,713,208', Active: 'No', dataofLaunch: '02/07/2017', genre: 'Science Fiction',
        hasTeaser: 'Yes'
    },

    {
        title: 'Avengers:End Game', boxOffice: '$2,750,760,348', Active: 'Yes', dataofLaunch: '02/11/2022', genre: 'Superhero',
        hasTeaser: 'Yes'
    }
];

let productFromStroage = localStorage.getItem('movies');
if (productFromStroage === null) {
    localStorage.setItem('movies', JSON.stringify(movies));
}
productFromStroage = JSON.parse(productFromStroage)
const renderProducts = function (productFromStroage) {
    let tabE1 = document.querySelector("#movie-tab");

    productFromStroage.forEach(function (movie) {
        let trow1 = document.createElement("tr");
        let tcol1 = document.createElement("td");
        tcol1.textContent = movie.title;
        trow1.appendChild(tcol1);

        let tcol2 = document.createElement("td");
        tcol2.textContent = movie.boxOffice;
        trow1.appendChild(tcol2);

        let tcol3 = document.createElement("td");
        tcol3.textContent = movie.Active;
        trow1.appendChild(tcol3);

        let tcol7 = document.createElement("td");
        tcol7.textContent = movie.dataofLaunch;
        trow1.appendChild(tcol7);

        let tcol5 = document.createElement("td");
        tcol5.textContent = movie.genre;
        trow1.appendChild(tcol5);

        let tcol6 = document.createElement("td");
        tcol6.textContent = movie.hasTeaser;
        trow1.appendChild(tcol6);

        let link = document.createElement("a");
        link.href = "edit-movie.html?" + "title=" + movie.title + "&boxOffice=" + movie.boxOffice + "&act=" + movie.Active + "&dol=" + movie.dataofLaunch + "&genre=" + movie.genre + "&hasTeaser=" + movie.hasTeaser;
        link.textContent = "Edit";
        let tcol4 = document.createElement("td");
        tcol4.appendChild(link);
        trow1.appendChild(tcol4);

        tabE1.appendChild(trow1);

    })


}
renderProducts(productFromStroage);