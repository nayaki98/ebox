var url_string = window.location.href; 

var url = 
new URL(url_string);


let title=url.searchParams.get('title');

let boxOffice=url.searchParams.get('boxOffice');

let active=url.searchParams.get('act');

let dol=url.searchParams.get('dol');

let genre=url.searchParams.get('genre');

let hasTeaser=url.searchParams.get('hasTeaser');

let titleText=document.querySelector('#title');

let boxOfficeText=document.querySelector('#boxOffice');

let dolText=document.querySelector('#dol');

let genreText=document.querySelector('#genre');

let hasTeaserText=document.querySelector('#hasTeaser');

titleText.setAttribute('value',title);

boxOfficeText.setAttribute('value',boxOffice);

dolText.setAttribute('value',dol)

var len = document.getElementById("genre").options.length;
var d=0;
for(var i=0;i<len;i++){
    var cat=genreText[i].value;
    if(genre==cat){
        d=i;
        break;
    }
}

var c=document.getElementById("genre");
c.value=genreText[d].value;

if (hasTeaser==="Yes")
    document.getElementById("hasTeaser").checked = true;
else
    document.getElementById("hasTeaser").checked = false;

if(active=="Yes")
    document.getElementById('activeYes').checked = true;
else
    document.getElementById('activeNo').checked = true;

document.querySelector('#save').addEventListener('click',function()

    {
    
        var title1=titleText.value;

      var boxOffice1=boxOfficeText.value;
      
        
        var dol1=dolText.value;
        var genre1=genreText.value;
        var hasTeaser1;
    
        let productsStrings=localStorage.getItem('movies');
        let movies=JSON.parse(productsStrings);
    let product=movies.find(function(product){
    
    return product.title===title1;
    })
    
    product.boxOffice=boxOffice1;
    let active1;
    if(document.getElementById('activeYes').checked)
    {
        active1="Yes";
    }
    else
    {
        active1="No";
    }
     
    if (document.getElementById("hasTeaser").checked)
    hasTeaser1="Yes"
    else
    hasTeaser1="No"
    
     product.Active=active1;

    product.dataofLaunch=dol1;

    product.genre=genre1;

    product.hasTeaser=hasTeaser1;
    
localStorage.removeItem('movies');
localStorage.setItem('movies',JSON.stringify(movies));
window.location="file:///C:/Users/765756/Desktop/final-check/WebContent/edit-movie-status.html";
    }) 
    