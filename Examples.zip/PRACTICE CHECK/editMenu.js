var url_string = window.location.href; 

var url = 
new URL(url_string);


let name=url.searchParams.get('name');

let price=url.searchParams.get('price');

let active=url.searchParams.get('act');

let dol=url.searchParams.get('dol');

let category=url.searchParams.get('category');

let delivery=url.searchParams.get('delivery');

let nameText=document.querySelector('#name');

let priceText=document.querySelector('#price');

let dolText=document.querySelector('#dol');

let categoryText=document.querySelector('#category');
//console.log(categoryText)

let deliveryText=document.querySelector('#delivery');

nameText.setAttribute('value',name);

priceText.setAttribute('value',price);

dolText.setAttribute('value',dol)

var len = document.getElementById("category").options.length;
var d=0;
for(var i=0;i<len;i++){
    var cat=categoryText[i].value;
    if(category==cat){
        d=i;
        break;
    }
}

var c=document.getElementById("category");
c.value=categoryText[d].value;

if (delivery==="Yes")
    document.getElementById("delivery").checked = true;
else
    document.getElementById("delivery").checked = false;

if(active=="Yes")
    document.getElementById('activeYes').checked = true;
else
    document.getElementById('activeNo').checked = true;

document.querySelector('#save').addEventListener('click',function()

    {
    
        var name1=nameText.value;

      var price1=priceText.value;
      
        
        var dol1=dolText.value;
        var category1=categoryText.value;
        var delivery1;
    
        let productsStrings=localStorage.getItem('products');
        let products=JSON.parse(productsStrings);
    let product=products.find(function(product){
    
    return product.name===name1;
    })
    
    product.price=price1;
    let active1;
    if(document.getElementById('activeYes').checked)
    {
        active1="Yes";
    }
    else
    {
        active1="No";
    }
     
    if (document.getElementById("delivery").checked)
    delivery1="Yes"
    else
    delivery1="No"
    
     product.Active=active1;

    product.dataofLaunch=dol1;

    product.Category=category1;

    product.freeDelivery=delivery1;
    
localStorage.removeItem('products');
localStorage.setItem('products',JSON.stringify(products));
window.location="file:///D:/PRACTICE%20CHECK/edit-menu-item-status.html";
    }) 
    