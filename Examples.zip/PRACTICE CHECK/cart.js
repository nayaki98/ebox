let productfromStorage=localStorage.getItem('products');
const listCart = function (productfromStorage) {
    var name=localStorage.getItem('name');

let products=JSON.parse(productfromStorage);
let product = products.find(function (product) {

    return product.name === name;

})
   
        let table = document.querySelector('#cart-tab');

        let tr = document.createElement('tr');

        let td1 = document.createElement('td');

        td1.textContent = product.name

        let td2 = document.createElement('td');
        td2.textContent = product.freeDelivery;

        let td3 = document.createElement('td');
        td3.textContent = product.price

        let td4 = document.createElement('td');
        let a = document.createElement('a');

        a.href = "cart-empty.html?name=" + product.name +  "&price=" + product.price +"&category=" + product.Category + "&delivery=" + product.freeDelivery;
        a.textContent = "Delete";
       td4.appendChild(a);
        tr.appendChild(td1);
        tr.appendChild(td2)
        tr.appendChild(td3);
        tr.appendChild(td4);  
        table.appendChild(tr);
}
listCart(productfromStorage);

